//import "jest"
import Chat from "./chat";

//Placeholder
describe("Chat JS", () => {
  beforeEach(() => {
    //Something
  });
  test("getActiveChats should be called", () => {
    expect(Chat.getActiveChats()).toBe(10);
  });
});
