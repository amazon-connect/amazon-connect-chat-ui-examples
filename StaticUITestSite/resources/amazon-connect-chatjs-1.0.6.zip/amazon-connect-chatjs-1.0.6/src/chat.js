import { CHAT_CONFIGURATIONS } from './constants';

//Placeholder
export default class Chat {
  static getActiveChats() {
    return CHAT_CONFIGURATIONS.CONCURRENT_CHATS;
  }
}
