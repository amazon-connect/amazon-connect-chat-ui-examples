/**
 * @file Custom error class with HTTP status code.
 */

class ErrorWithStatusCode extends Error {
  constructor (message, statusCode = 500) {
    super(message);

    // Saving class name in the property of the custom error as a shortcut.
    this.name = this.constructor.name;

    // Capturing stack trace, excluding constructor call from it.
    Error.captureStackTrace(this, this.constructor);

    this.statusCode = statusCode;
  }
}

module.exports = {
  ErrorWithStatusCode
};