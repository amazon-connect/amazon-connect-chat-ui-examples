/**
 * @file Contains primary functionality. Exports getLinkPreviewData, which is the
 * method expected to be consumed by the lambda handler.
 */

const messageUtils = require('./utils/message');
const dataFetchManager = require('./utils/dataFetchManager');
const inputValidator = require('./utils/inputValidator');
const ERRORS = require('./constants/errors');
const { ErrorWithStatusCode } = require('./errors/ErrorWithStatusCode');

/**
 * Starts timeout timer, validates input, then calls getLinkPreviewDataFromMessageWithOptions(...).
 *
 * getLinkPreviewData(...) returns a promise with 2 possible outcomes:
 *  1) RESOLVED: Returns link preview data for every url as a JSON
 *       (required)(string) title
 *       (optional)(base64string) image
 *       (required)(string) url
 *       (optional)(string) shortUrl (substring of URL: index 0 through TLD))
 *       (optional)(string) description
 *     Fields marked (required) will always have content
 *     Fields marked (optional) may be null
 *  2) REJECTED: error thrown during process or timeout
 *
 * @param   {string}  message   inputted from user
 * @param   {Object}  options   could contain any subset of the following options:
 *                              {
 *                                  timeoutMs,
 *                                  maxTitleLength,
 *                                  maxDescriptionLength,
 *                                  maxUrlCount,
 *                                  shouldValidateImagePreDownload,
 *                                  minHeight
 *                                  minAspectRatio,
 *                                  maxAspectRatio,
 *                                  maxImageSizeBytes
 *                              }
 * @returns a promise that resolves to link preview data or rejects due to an error or timeout
 * @exception invalid input: empty message or null message
*/
function getLinkPreviewData(message = '', options = {}) {
  console.log(`getLinkPreviewData {message : ${message}, `
    + `options: ${JSON.stringify(options)}}`);

  message = inputValidator.validateMessage(message);
  const {
    timeoutMs,
    maxTitleLength,
    maxDescriptionLength,
    maxUrlCount,
    shouldValidateImagePreDownload,
    minHeight,
    minAspectRatio,
    maxAspectRatio,
    maxImageSizeBytes
  } = inputValidator.validateOptions(options);

  // Enables timeout capability
  return Promise.race([
    getTimeout(timeoutMs),
    getLinkPreviewDataFromMessageWithOptions(
      message,
      {
        maxTitleLength,
        maxDescriptionLength,
        maxUrlCount,
      },
      {
        minHeight,
        minAspectRatio,
        maxAspectRatio,
        maxImageSizeBytes
      },
      shouldValidateImagePreDownload
    )
  ]);
}

/**
 * Provides timeout for method execution time. Aborts execution and returns 408
 * error to caller if timeout is reached before data is returned.
 * @param   {number}  timeoutMs   length of timeout in ms
 * @returns {Promise} timeout
 */
function getTimeout(timeoutMs) {
  console.log(`getTimeout {timeoutMs : ${timeoutMs}}`);

  return new Promise((resolve, reject) => {
    setTimeout(reject, timeoutMs,
      new ErrorWithStatusCode(`Rich link data fetch timed out in ${timeoutMs} ms.`, ERRORS.REQUEST_TIMEOUT));
  });
}

/**
 * Extracts urls from message then calls getSingleUrlMetadata(...) on each one
 * to fetch preview metadata for each url.
 * @param {string}  message         input message from user
 * @param {Object}  generalOptions  input generalOptions from user (all options not related to images)
 * @param {Object}  imageOptions    input imageOptions from user (all options related to images)
 * @param {boolean} shouldValidateImagePreDownload true if image dimensions, aspect ratio,
 *                                                 and size should be checked pre-download
 * @returns array of objects containing preview metadata for each url
 * @exception getUrlsFromMessage: message contains either 0 urls, non-url text, or more urls than maxUrlCount
 * @exception getSingleUrlMetadata: fails to retrieve metadata for 1+ urls
 */
async function getLinkPreviewDataFromMessageWithOptions(message, generalOptions, imageOptions, shouldValidateImagePreDownload) {
  console.log(`getLinkPreviewDataFromMessageWithOptions {message : ${message},`
    + `generalOptions : ${JSON.stringify(generalOptions)}, `
    + `imageOptions : ${JSON.stringify(imageOptions)}, `
    + `shouldValidateImagePreDownload : ${JSON.stringify(shouldValidateImagePreDownload)}}`);

  // Builds array of urls that need link preview data then fetches data for all urls in parallel
  const messageUrls = messageUtils.getUrlsFromMessage(message, generalOptions.maxUrlCount);
  const dataFetches = messageUrls.map(url => dataFetchManager.getSingleUrlMetadata(url, generalOptions, imageOptions, shouldValidateImagePreDownload));
  const linkPreviewData = await Promise.all(dataFetches);

  return linkPreviewData;
}

module.exports = {
  getLinkPreviewData
};