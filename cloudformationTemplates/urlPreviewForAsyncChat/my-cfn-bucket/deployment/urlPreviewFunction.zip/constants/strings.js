/**
 * @file Contains all string constants.
 */

const ELLIPSIS = '...';
const EMPTY_STRING = '';

module.exports = {
  ELLIPSIS,
  EMPTY_STRING
};
