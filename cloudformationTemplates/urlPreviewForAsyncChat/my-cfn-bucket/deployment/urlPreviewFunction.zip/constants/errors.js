/**
 * @file Maps error messages to error numbers.
 */

const BAD_REQUEST = 400;
const NOT_FOUND = 404;
const REQUEST_TIMEOUT = 408;
const INTERNAL_SERVER_ERROR = 500;

module.exports = {
  BAD_REQUEST,
  NOT_FOUND,
  REQUEST_TIMEOUT,
  INTERNAL_SERVER_ERROR
};
