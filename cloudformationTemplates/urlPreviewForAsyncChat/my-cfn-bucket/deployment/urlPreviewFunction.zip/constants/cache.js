/**
 * @file Contains all constants related to the cache and cache management.
 */

const TABLE_NAME = process.env.CACHE_TABLE;
const PRIMARY_KEY = process.env.PRIMARY_KEY;
const METADATA_COLUMN_NAME = 'metadata';
const TTL_COLUMN_NAME = 'ttl';

// This is 30 days in seconds
const DEFAULT_TTL = 2592000;

const MILLISECONDS_PER_SECOND = 1000;

const NULL_METADATA_OBJECT = {
  url: null,
  shortUrl: null,
  description: null,
  title: null,
  image: null
};

module.exports = {
  TABLE_NAME,
  PRIMARY_KEY,
  METADATA_COLUMN_NAME,
  TTL_COLUMN_NAME,
  DEFAULT_TTL,
  MILLISECONDS_PER_SECOND,
  NULL_METADATA_OBJECT
};
