/**
 * @file Contains all constants related to urls and url processing.
 */

const RECOGNIZED_TLDS = [
  // 6 most common universal TLDs
  'com', 'gov', 'org', 'net', 'edu', 'mil',
  // 16 most common country TLDs
  'ca', 'cn', 'fr', 'ch', 'au', 'in',
  'de', 'jp', 'nl', 'uk', 'mx', 'no',
  'ru', 'br', 'se', 'es', 'co.uk'
];

const PREFIXES = {
  'WWW': 'www',
  'HTTP': 'http://',
  'HTTPS': 'https://'
};

const WWW_LENGTH = 3;

const AMAZON_RETAIL_URL_WITHOUT_TLD = 'www.amazon';

module.exports = {
  RECOGNIZED_TLDS,
  PREFIXES,
  WWW_LENGTH,
  AMAZON_RETAIL_URL_WITHOUT_TLD
};
