/**
 * @file Contains all constants related to image to base64 string processing.
 */

const FILETYPE_IDENTIFIER_LENGTH = 3;

const FILETYPE_IDENTIFIER = {
  JPEG: '/9j',
  PNG: 'iVB'
};

const URI_PREFIX = {
  JPEG: 'data:image/jpeg;base64,',
  PNG: 'data:image/png;base64,',
};

module.exports = {
  FILETYPE_IDENTIFIER_LENGTH,
  FILETYPE_IDENTIFIER,
  URI_PREFIX,
};
