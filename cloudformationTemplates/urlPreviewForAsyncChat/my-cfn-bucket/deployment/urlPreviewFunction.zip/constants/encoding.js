/**
 * Contains constants for different primitive encoding schemes.
 */

const BASE10 = 10;
const BASE64 = 'base64';

module.exports = {
  BASE10,
  BASE64
};
