/**
 * @file Contains all constants related to image downloading.
 */

const UNITS = {
  PIXELS: 'px'
};

const FILESIZE_CONSTANT_DIMENSION_MULTIPLIER = 3;
const FILESIZE_CONSTANT_MAX_MULTIPLIER = 3;

module.exports = {
  UNITS,
  FILESIZE_CONSTANT_DIMENSION_MULTIPLIER,
  FILESIZE_CONSTANT_MAX_MULTIPLIER
};