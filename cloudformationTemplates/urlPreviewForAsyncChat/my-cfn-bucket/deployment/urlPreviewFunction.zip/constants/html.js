/**
 * @file Contains all constants related to html fetching and processing.
 */

const TAGS = {
  OG_TITLE: 'og:title',
  TWITTER_TITLE: 'twitter:title',
  HTML_TITLE: '<title>',
  OG_DESCRIPTION: 'og:description',
  TWITTER_DESCRIPTION: 'twitter:description',
  META_DESCRIPTION: 'meta name="description"',
  OG_IMAGE: 'og:image',
  AMAZON_IMAGE_TAG: 'data-old-hires'
};

const UNICODE_CHAR_MAPPING = {
  '33': '!',
  'x21': '!',
  'excl': '!',
  '34': '"',
  'x22': '"',
  'quot': '"',
  '35': '#',
  'x23': '#',
  'num': '#',
  '36': '$',
  'x24': '$',
  'dollar': '$',
  '38': '&',
  'x26': '&',
  'amp': '&',
  '39': '\'',
  'x27': '\'',
  'apos': '\'',
  '40': '(',
  'x28': '(',
  'lpar': '(',
  '41': ')',
  'x29': ')',
  'rpar': ')',
  '42': '*',
  'x2a': '*',
  'ast': '*',
  '43': '+',
  'x2b': '+',
  'plus': '+',
  '44': ',',
  'x2c': ',',
  'comma': ',',
  '45': '-',
  'x2d': '-',
  'hyphen': '-',
  'dash': '-',
  '46': '.',
  'x2e': '.',
  'period': '.',
  'x2122': '™',
  'trade': '™',
  '169': '©',
  'xa9': '©',
  'copy': '©',
  '174': '®',
  'xae': '®',
  'reg': '®'
};

const FETCH_PARAMETERS = {
  TIMEOUT_MS: 3000,
  MAX_SIZE_BYTES: 3e6
};

module.exports = {
  TAGS,
  UNICODE_CHAR_MAPPING,
  FETCH_PARAMETERS
};