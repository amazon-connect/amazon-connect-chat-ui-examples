/**
 * @file Contains all symbol constants
 */

const FORWARD_SLASH = '/';
const PLUS_SIGN = '+';
const PERIOD = '.';

module.exports = {
  FORWARD_SLASH,
  PLUS_SIGN,
  PERIOD
};