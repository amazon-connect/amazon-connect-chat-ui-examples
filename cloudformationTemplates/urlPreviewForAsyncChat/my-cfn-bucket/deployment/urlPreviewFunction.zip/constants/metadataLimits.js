/**
 * @file Contains constants defining hard limits for metadata parameters.
 */

const MINIMUM = {
  // Input options
  TIMEOUT_MS: 250,
  MAX_TITLE_LENGTH: 10,
  MAX_DESCRIPTION_LENGTH: 25,
  MAX_URL_COUNT: 1,
  MIN_HEIGHT: 50,
  MIN_ASPECT_RATIO: .25,
  MAX_ASPECT_RATIO: .25,
  MAX_IMAGE_SIZE_BYTES: 1e5,

  // Metadata
  TITLE_LENGTH: 3,
  DESCRIPTION_LENGTH: 8,
};

const MAXIMUM = {
  TIMEOUT_MS: 10000,
  MAX_TITLE_LENGTH: 250,
  MAX_DESCRIPTION_LENGTH: 250,
  MAX_URL_COUNT: 10,
  MIN_HEIGHT: 1000,
  MIN_ASPECT_RATIO: 4,
  MAX_ASPECT_RATIO: 4,
  MAX_IMAGE_SIZE_BYTES: 2e7,
};

module.exports = {
  MINIMUM,
  MAXIMUM
};
