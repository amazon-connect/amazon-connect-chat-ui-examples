/**
 * @file Contains all regexes.
 */

const WORD_DELIMETER = /\s+/;
const SPACE_GLOBAL = /\s+/g;
const SPACE_PERCENT_ENCODED = /(%20)+/g;
const NUMBER = /\d/;

const URL_STRICT = /^(www.|http:\/\/|https:\/\/).+/;
const HTML_CHARACTER = /&#?(\w+);/ig;
const UTM_TAG = /^utm_\w+/i;

const DOUBLE_SLASHES = /\/\//g;
const DOT_SEGMENT = /(\/.\/)|(\/..\/)/g;
const PLUS_SIGN = /(\+)+/g;

const PORT_80 = /( =80){1}/;
const PORT_443 = /( =443){1}/;

module.exports = {
  WORD_DELIMETER,
  SPACE_GLOBAL,
  SPACE_PERCENT_ENCODED,
  NUMBER,
  URL_STRICT,
  HTML_CHARACTER,
  UTM_TAG,
  DOUBLE_SLASHES,
  DOT_SEGMENT,
  PLUS_SIGN,
  PORT_80,
  PORT_443
};