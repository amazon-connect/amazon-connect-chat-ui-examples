/**
 * @file Contains default values in event that user does not provide some/all options.
 */

const IMAGE = {
  SHOULD_VALIDATE_IMAGE_PRE_DOWNLOAD: true,
  MIN_HEIGHT: 200,
  MAX_ASPECT_RATIO: 2.35,
  MIN_ASPECT_RATIO: 0.75,
  MAX_IMAGE_SIZE_BYTES: 5e6
};

const METADATA = {
  MAX_TITLE_LENGTH: 75,
  MAX_DESCRIPTION_LENGTH: 150
};

const MESSAGE = {
  MAX_URL_COUNT: 3
};

const TIMEOUT_MS = 3000;

module.exports = {
  IMAGE,
  METADATA,
  MESSAGE,
  TIMEOUT_MS
};
