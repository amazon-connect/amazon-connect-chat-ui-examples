/**
 * @file Handler that takes input from an Amazon API Gateway, validates it, calls
 * index.js, formats the return data, and returns an HTTP response.
 */

const { getLinkPreviewData } = require('./index');

/**
 * Takes input from API gateway, validates, and returns.
 * @param {Object}  event   input from API Gateway
 * @returns {Object} HTTP response of format:
 *                      {
 *                        statusCode: int,
 *                        body: string
 *                      }
 */
async function handler(event) {
  console.log(`AmazonConnectChatLambdaEntryPoint handler {event: ${JSON.stringify(event)}}`);
  const body = JSON.parse(event['body']);
  const message = body['message'] || '';
  const options = body['options'] || {};
  const headers = {
    "Content-Type": "application/json"
    };
  console.log(`handler {message : ${message}, options : ${options}`);

  let response;
  try {
    const linkPreviewData = await getLinkPreviewData(message, options);
    const statusCodeContent = 200;
    const formattedLinkPreviewData = Object.assign({}, linkPreviewData);
    
    response = {
      'statusCode': statusCodeContent,
      'body': JSON.stringify(formattedLinkPreviewData),
      'headers': headers,
      "isBase64Encoded": false
    };
  } catch (error) {
    const errorString = error.toString();
    const errorStatusCode = error.statusCode;

    response = {
      'statusCode': errorStatusCode,
      'body': JSON.stringify(errorString),
      'headers': headers,
      "isBase64Encoded": false
    };
  }

  console.log(`Returning the following:\n${JSON.stringify(response)}`);
  return response;
}

module.exports = {
  handler
};