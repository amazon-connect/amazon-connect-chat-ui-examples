/**
 * @file Manages fetching of metadata at a high level.
 */

const imageUtils = require('./image');
const metadataUtils = require ('./metadata');
const cacheManager = require('./cacheManager');
const urlNormalizer = require('./urlNormalizer');

/**
 * Fetches preview data for input url
 * @param   {string}  targetUrl       url to retrieve metadata for
 * @param   {Object}  generalOptions  options not related to images, inputted by user
 * @param   {Object}  imageOptions    options related to images, inputted by user
 * @returns {Object}  containing preview metadata for targetUrl. Object format:
 *                    {
 *                      url: string,
 *                      title: string,
 *                      description: string,
 *                      shortUrl: string,
 *                      image: string
 *                    }
 */
async function getSingleUrlMetadata(targetUrl, generalOptions, imageOptions, shouldValidateImagePreDownload) {
  console.log(`getSingleUrlMetadata {targetUrl: ${targetUrl}, `
        + `generalOptions : ${JSON.stringify(generalOptions)}, `
        + `imageOptions : ${JSON.stringify(imageOptions)}, `
        + `shouldValidateImagePreDownload : ${JSON.stringify(shouldValidateImagePreDownload)}}`);

  const normalizedTargetUrl = urlNormalizer.normalizeUrlFully(targetUrl);
  cacheManager.updateConfiguration(); // Ensures cache manager is setup

  const metadata = {};
  try {
    Object.assign(metadata, await getSingleUrlMetadataFromCache(normalizedTargetUrl, generalOptions, imageOptions, shouldValidateImagePreDownload));
  } catch (error) {
    /**
     * If url doesn't exist in cache, an error will be thrown. This error is caught
     * and logged, then the html of the url is downloaded, scraped, and the url's
     * metadata is uploaded to the cache.
     */
    console.error(error);
    const html = await metadataUtils.getHtmlFromUrl(normalizedTargetUrl);
    Object.assign(metadata, metadataUtils.getUrlMetadata(html, normalizedTargetUrl));

    try {
      await cacheManager.putMetadata(metadata);
    } catch (error) {
      console.error(error);
    }
  }

  try {
    metadata.shortUrl = metadataUtils.getShortUrl(normalizedTargetUrl);
  } catch (error) {
    console.error(error);
    metadata.shortUrl = null;
  }

  /**
     * The following lines attempt to assign data to different keys of metadata.
     * Title is a required field; therefore, errors thrown from formatTitle are not
     * caught and abort execution (this shouldn't occur, as title errors should be
     * caught at scraping).
     *
     * Description, shortUrl, and image are not required fields; therefore, in the
     * event any of their respective methods throws an error, the error is caught,
     * logged, and the respective key value is set to null.
     */
  metadata.title = metadataUtils.formatTitle(metadata.title, generalOptions.maxTitleLength);

  try {
    metadata.description = metadataUtils.formatDescription(metadata.description, generalOptions.maxDescriptionLength);
  } catch (error) {
    console.error(error);
    metadata.description = null;
  }

  try {
    metadata.image = await imageUtils.getImage(metadata.image, imageOptions, shouldValidateImagePreDownload);
  } catch (error) {
    console.error(error);
    metadata.image = null;
  }

  // Original url returned instead of normalizedUrl to prevent edge cases
  metadata.url = targetUrl;

  return metadata;
}

/**
 * Attempts to fetch metadata for url from cache, throws exception if not found.
 * @param   {string}  targetUrl       url to retrieve metadata for
 * @param   {Object}  generalOptions  options not related to images, inputted by user
 * @param   {Object}  imageOptions    options related to images, inputted by user
 * @param   {boolean} shouldValidateImagePreDownload true if image dimensions, aspect ratio,
 *                                                 and size should be checked pre-download
 * @returns {Object}  containing preview metadata for targetUrl. Object format:
 *                    {
 *                      url: string,
 *                      title: string,
 *                      description: string,
 *                      shortUrl: string,
 *                      image: string
 *                    }
 * @exception data not found in cache or error in data fetch
 */
async function getSingleUrlMetadataFromCache(targetUrl, generalOptions, imageOptions, shouldValidateImagePreDownload) {
  console.log(`getSingleUrlMetadataFromCache {targetUrl: ${targetUrl}, `
        + `generalOptions : ${JSON.stringify(generalOptions)}, `
        + `imageOptions : ${JSON.stringify(imageOptions)}, `
        + `shouldValidateImagePreDownload : ${JSON.stringify(shouldValidateImagePreDownload)}}`);

  const cacheItem = await cacheManager.getMetadata(targetUrl);
  // Converts data from cache response object to expected metadata format
  const metadata = cacheManager.parseMetadataItemFromCache(cacheItem);

  return metadata;
}

module.exports = {
  getSingleUrlMetadata
};