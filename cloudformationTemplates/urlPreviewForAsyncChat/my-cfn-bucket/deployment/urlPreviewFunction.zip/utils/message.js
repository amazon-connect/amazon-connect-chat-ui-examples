/**
 * @file Handles extraction of urls, url validation, and url modification.
 */

const REGEXES = require('./../constants/regexes');
const URL = require('./../constants/url');
const ERRORS = require('./../constants/errors');
const { ErrorWithStatusCode } = require('./../errors/ErrorWithStatusCode');

/**
 * Extracts urls from message, checks if number of urls is within bounds, verifies
 * that the message has no other text, then returns list of urls. If any condition
 * is not met, returns null.
 * @param   {string}    message       raw message from user
 * @param   {number}    maxUrlCount   maximum number of urls allowed to be extracted
 * @returns {String[]}  array of urls extracted from message
 * @exception   no urls found, number of urls found > maxUrlCount, message contains non-url text
 */
function getUrlsFromMessage(message, maxUrlCount) {
  console.log(`getUrlsFromMessage {message : ${message}, `
    + `maxUrlCount : ${maxUrlCount}}`);

  message = message.trim();
  const messageUrlsRaw = getSetOfUrlsFromString(message);

  if (messageUrlsRaw.length === 0) {
    throw new ErrorWithStatusCode(` User input "message" with value "${message}" `
    + 'contained 0 urls beginning with "www.", "http://", or "https://"', ERRORS.BAD_REQUEST);
  }

  const messageUrlsWithHttps = replaceWwwWithHttps(messageUrlsRaw);
  if (messageUrlsWithHttps.length > maxUrlCount) {
    throw new ErrorWithStatusCode(` User input "message" with value "${message}" `
        + `contained "${messageUrlsWithHttps.length} urls, which is greater than "maxUrlCount" `
        + `with value "${maxUrlCount}`, ERRORS.BAD_REQUEST);
  }
  if (message.split(REGEXES.WORD_DELIMETER).length > messageUrlsWithHttps.length) {
    throw new ErrorWithStatusCode(` User input "message" with value "${message}" `
        + 'contains non-url text.', ERRORS.BAD_REQUEST);
  }

  return messageUrlsWithHttps;
}

/**
 * Returns list of urls found in inputString.
 * @param     {string}  inputString   string to be searched for urls
 * @returns   {string[]}  array of urls extracted from string
 */
function getSetOfUrlsFromString(inputString) {
  console.log(`getSetOfUrlsFromString {inputString : ${inputString}}`);

  const inputStringAsArray = inputString.split(REGEXES.WORD_DELIMETER);
  const urls = inputStringAsArray.filter(singleWord => isValidUrl(singleWord));

  return urls;
}

/**
 * Returns true if url begins with 'www.', 'http://', or 'https://', false otherwise.
 * @param   {string}  inputString   url to be checked
 * @returns {boolean} true if url begins with 'www.', 'http://', or 'https://', false otherwise
 */
function isValidUrl(inputString) {
  console.log(`isValidUrl {inputString : ${inputString}}`);

  if (inputString === null) {
    return false;
  }

  return inputString.search(REGEXES.URL_STRICT) === 0;
}

/**
 * Replaces 'www.' with 'https://' for all urls that begin with 'www'
 *
 * Sample input:
 * www.aws.amazon.com
 *
 * Sample output:
 * https://aws.amazon.com
 *
 * @param   {String[]}  urlArray  array of urls that could start with 'www.',
 *                                'https://', or 'http://' only
 * @returns {String[]}  array of urls that starts with 'https://' or 'http://' only
 */
function replaceWwwWithHttps(urlArray) {
  console.log(`replaceWwwWithHttps {urlArray : ${urlArray}}`);

  urlArray.forEach( (singleUrl, index) => {
    if (singleUrl.substring(0,URL.WWW_LENGTH) === URL.PREFIXES.WWW) {
      // The '+ 1' in the substring accounts for the '.' after 'www'
      urlArray[index] = URL.PREFIXES.HTTPS + singleUrl.substring(URL.WWW_LENGTH + 1);
    }
  });

  return urlArray;
}

module.exports = {
  getUrlsFromMessage,
  isValidUrl
};