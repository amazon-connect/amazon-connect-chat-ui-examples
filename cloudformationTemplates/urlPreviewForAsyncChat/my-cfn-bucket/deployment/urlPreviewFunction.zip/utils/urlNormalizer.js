/**
 * @file Contains functionality to normalize urls as detailed in RFC 3986, section 6.
 * The purpose of this is to reduce the number of urls that have different
 * characters but ultimately resolve to the same location.
 *
 * Reference: https://tools.ietf.org/html/rfc3986#page-38
 */

const REGEXES = require('./../constants/regexes');
const SYMBOLS = require('./../constants/symbols');

/**
 * Removes dot segments in urls using regex.
 *
 * Example input:
 * http://www.example.com/a/./b/../c
 *
 * Example output:
 * http://www.example.com/a/b/c
 *
 * @param   {URL}    nodeUrl   to be modified
 * @returns {URL}    Node url with dot segments removed
 */
function removeDotSegments(nodeUrl) {
  nodeUrl.href = nodeUrl.href.replace(REGEXES.DOT_SEGMENT, SYMBOLS.FORWARD_SLASH);
  return nodeUrl;
}

/**
 * Makes all characters in host and protocol lowercase using url-parse.
 *
 * Example input:
 * http://Www.Example.Com
 *
 * Example output:
 * http://www.example.com
 *
 * @param   {URL}    nodeUrl   to be modified
 * @returns {URL}    Node url with all characters in host and protocol lowercase
 */
function setHostAndProtocolToLowercase(nodeUrl) {
  nodeUrl.hostname = nodeUrl.hostname.toLowerCase();
  nodeUrl.protocol = nodeUrl.protocol.toLowerCase();
  return nodeUrl;
}

/**
 * Removes double slashes using url parse and regex.
 *
 * Example input:
 * http://www.example.com/some//path
 *
 * Example output:
 * http://www.example.com/some/path
 *
 * @param   {URL}    nodeUrl   to be modified
 * @returns {URL}    Node url with double slashes removed
 */
function removeDoubleSlashes(nodeUrl) {
  // The '+2' in the following line moves the index past the double slashes following the protocol
  const urlBeforeProtocol = nodeUrl.href.substring(0, nodeUrl.protocol.length + 2);
  const urlAfterProtocol = nodeUrl.href.substring(urlBeforeProtocol.length);
  nodeUrl.href = urlBeforeProtocol
      + urlAfterProtocol.replace(REGEXES.DOUBLE_SLASHES, SYMBOLS.FORWARD_SLASH);
  return nodeUrl;
}

/**
 * Changes space sign in query to plus sign using url-parse and regex.
 *
 * Example input:
 * http://www.example.com/?q=hello world  hello   world
 *
 * Example output:
 * http://www.example.com/?q=hello+world
 *
 * @param   {URL}    nodeUrl   to be modified
 * @returns {URL}    Node url with space sign changed to plus sign in query
 */
function setSpaceToPlusInQuery(nodeUrl) {
  nodeUrl.search = nodeUrl.search.replace(REGEXES.SPACE_PERCENT_ENCODED, SYMBOLS.PLUS_SIGN)
    .replace(REGEXES.PLUS_SIGN, SYMBOLS.PLUS_SIGN);
  return nodeUrl;
}

/**
 * Removes equal sign in query parameter if query is empty using url-parse and regex.
 *
 * Example input:
 * http://www.example.com/?q=
 *
 * Example output:
 * http://www.example.com/?q
 *
 * @param   {URL}    nodeUrl   to be modified
 * @returns {URL}    Node url without equals sign in query parameter if query is empty
 */
function removeEqualSignFromEmptyQueryParameter(nodeUrl) {
  if (nodeUrl.search === '?q=') {
    nodeUrl.search = '?q';
  }
  return nodeUrl;
}

/**
 * Removes question mark in query if query is empty using url-parse and regex.
 *
 * Example input 1:
 * http://www.example.com/?
 *
 * Example output 1:
 * http://www.example.com/
 *
 * Example input 2:
 * http://www.example.com/?q
 *
 * Example output 2:
 * http://www.example.com/
 *
 * @param   {URL}    nodeUrl   to be modified
 * @returns {URL}    Node url without question mark in query if query is empty
 */
function removeQuestionMarkFromEmptyQuery(nodeUrl) {
  if (nodeUrl.href.substring(nodeUrl.href.length - 1) === '?') {
    nodeUrl.href = nodeUrl.href.substring(0, nodeUrl.href.length - 1);
  }
  if (nodeUrl.href.substring(nodeUrl.href.length - 2) === '?q') {
    nodeUrl.href = nodeUrl.href.substring(0, nodeUrl.href.length - 2);
  }
  return nodeUrl;
}

/**
 * Remove utm analytics tracking tags using normalize-url.
 *
 * Example input:
 * https://www.google.com/?a=2&utm_source=active%20users&utm_medium=email&utm_campaign=feature%20launch&utm_content=bottom%20cta%20button
 *
 * Example output:
 * https://www.google.com/?a=2
 *
 * @param   {URL}    nodeUrl   to be modified
 * @returns {URL}    Node url without utm tracking tags
 */
function removeUtmTrackingTags(nodeUrl) {
  let newParams = new URLSearchParams();
  nodeUrl.searchParams.forEach((value, key) => {
    if (!key.match(REGEXES.UTM_TAG)) {
      newParams.append(key, value);
    }
  });
  nodeUrl.search = newParams.toString();
  return nodeUrl;
}

/**
 * Sorts query parameters using normalize-url.
 *
 * Example input:
 * http://www.example.com/?b=1&a=2
 *
 * Example output:
 * http://www.example.com/?a=2&b=1
 *
 * @param   {URL}    nodeUrl   to be modified
 * @returns {URL}    Node url with query parameters sorted
 */
function sortQueryParameters(nodeUrl) {
  nodeUrl.searchParams.sort(nodeUrl);
  return nodeUrl;
}

/**
 * Returns url href.
 * @param   {URL}     nodeUrl   to be stringified
 * @returns {string}  stringified node url
 */
function nodeUrlToString(nodeUrl) {
  return nodeUrl.href;
}

/**
 * Applies all url normalization operations to the url parameter.
 * @param   {string}  url   to be normalized
 * @returns {string}  normalized url
 */
function normalizeUrlFully(url) {
  console.log(`normalizeUrlFully {url : ${url}`);

  /**
   * When this NodeJS url is constructed, it automatically removes default ports
   * and converts non-ASCII characters to ASCII characters using the Punycode
   * algorithm.
   *
   * NodeJS URL reference: https://nodejs.org/api/url.html#url_percent_encoding_in_urls
   * Punycode reference: https://tools.ietf.org/html/rfc5891#section-4.4
   */
  let nodeUrl = new URL(url);
  nodeUrl = removeDotSegments(nodeUrl);
  nodeUrl = setHostAndProtocolToLowercase(nodeUrl);
  nodeUrl = removeDoubleSlashes(nodeUrl);
  nodeUrl = setSpaceToPlusInQuery(nodeUrl);
  nodeUrl = removeEqualSignFromEmptyQueryParameter(nodeUrl);
  nodeUrl = removeQuestionMarkFromEmptyQuery(nodeUrl);
  nodeUrl = removeUtmTrackingTags(nodeUrl);
  nodeUrl = sortQueryParameters(nodeUrl);

  return nodeUrl.href;
}

module.exports = {
  // The normalizeUrlFully function is consumed in index.js
  normalizeUrlFully,
  // All functions below this comment are exported solely for testing purposes.
  removeDotSegments,
  setHostAndProtocolToLowercase,
  removeDoubleSlashes,
  setSpaceToPlusInQuery,
  removeEqualSignFromEmptyQueryParameter,
  removeQuestionMarkFromEmptyQuery,
  removeUtmTrackingTags,
  sortQueryParameters,
  nodeUrlToString
};
