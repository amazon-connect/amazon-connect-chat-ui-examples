/**
 * @file Handles image validation, downloading, and conversion to base64.
 */

const probeImageSize = require('probe-image-size');
const messageUtils = require('./message');
const fetch = require('node-fetch');
const BASE64 = require('./../constants/base64');
const ENCODING = require('./../constants/encoding');
const IMAGE = require('./../constants/image');
const ERRORS = require('./../constants/errors');
const { ErrorWithStatusCode } = require('./../errors/ErrorWithStatusCode');

/**
 * Attempts to download image at 'imageUrl' and convert to base64 encoded string.
 * @param {string}    imageUrl                          url of image to download
 * @param {Object}    imageDimensionAndFilesizeOptions  {minHeight, minAspectRatio, maxAspectRatio, maxImageSizeBytes}
 * @param {boolean}   shouldValidateImagePreDownload    determines if image dimension etc. should be checked pre-download
 *                                                      if false, performance improvement of 1000-2000ms/image
 * @returns {string}  base64 encoded image
 * @exception image not within values in imageDimensionAndFilesizeOptions, image download failed
 */
async function getImage(imageUrl, imageDimensionAndFilesizeOptions, shouldValidateImagePreDownload) {
  console.log(`getImageUsingRules {imageUrl : ${imageUrl}, `
    + `imageOptions : ${JSON.stringify(imageDimensionAndFilesizeOptions)}, `
    + `shouldValidateImagePreDownload : ${JSON.stringify(shouldValidateImagePreDownload)}}`);

  if (!(messageUtils.isValidUrl(imageUrl))) {
    throw new ErrorWithStatusCode('Image url is null.', ERRORS.BAD_REQUEST);
  }

  /**
   * Checking image file size, dimensions, and aspect ratios is a time-expensive
   * task, therefore offering the users an option to skip it in order to reduce
   * latency by 1000-2000ms.
   */
  if (shouldValidateImagePreDownload) {
    // This dimension fetch specifically is the time-expensive operation.
    const dimensions = await getImageDimensions(imageUrl);

    if (!(imageFilesizeWithinBounds(dimensions, imageDimensionAndFilesizeOptions))) {
      throw new ErrorWithStatusCode('Image file size not within bounds.', ERRORS.INTERNAL_SERVER_ERROR);
    }
    if (!(imageDimensionsValid(dimensions, imageDimensionAndFilesizeOptions))) {
      throw new ErrorWithStatusCode(' Image dimensions invalid. '
      + `{dimensions = "${JSON.stringify(dimensions)}", `
      + `imageOptions = "${JSON.stringify(imageDimensionAndFilesizeOptions)}"}.`, ERRORS.INTERNAL_SERVER_ERROR);
    }
  }

  const base64Image = await imageUrlToBase64Image(imageUrl, {size: imageDimensionAndFilesizeOptions.maxImageSizeBytes});
  const base64ImageWithUriPrefix = prependUriPrefixToBase64Image(base64Image);

  return base64ImageWithUriPrefix;
}

/**
 * Retrieves dimensions for image at imageUrl without downloading image.
 * @param imageUrl
 * @returns {Object}  containing image dimensions: {width: number, height: number}
 * @exception image dimensions unable to be fetched
 */
async function getImageDimensions(imageUrl) {
  console.log(`getImageDimensions {imageUrl : ${imageUrl}}`);

  let imageInfo;
  try {
    imageInfo = await probeImageSize(imageUrl);
  } catch (error) {
    throw new ErrorWithStatusCode('Failed to retrieve image dimensions.', ERRORS.INTERNAL_SERVER_ERROR);
  }

  if (imageInfo.wUnits === IMAGE.UNITS.PIXELS
      && imageInfo.hUnits === IMAGE.UNITS.PIXELS
      && imageInfo.width && imageInfo.height) {
    return {width: imageInfo.width, height: imageInfo.height};
  } else {
    throw new ErrorWithStatusCode('Image dimensions have incorrect units or don\'t exist'
        + `{imageUrl : "${imageUrl}", image info : "${imageInfo}"}.`, ERRORS.INTERNAL_SERVER_ERROR);
  }
}

/**
 * Estimates file size using dimensions. Checks for images of extremely high resolution
 * to prevent downloading if it's almost certain they'll be above the file size limit
 * @param   {Object}  dimensions    of image {width: number, height: number}
 * @param   {Object}  imageOptions  that contains maxImageSizeBytes
 * @returns {boolean} true if image is within file size bounds, false otherwise
 */
function imageFilesizeWithinBounds(dimensions, imageOptions) {
  console.log(`imageFilesizeWithinBounds {dimensions: ${JSON.stringify(dimensions)}, `
    + `imageOptions : ${JSON.stringify(imageOptions)}}`);

  if ((dimensions.width * dimensions.height * IMAGE.FILESIZE_CONSTANT_DIMENSION_MULTIPLIER)
      > imageOptions.maxImageSizeBytes * IMAGE.FILESIZE_CONSTANT_MAX_MULTIPLIER) {
    return false;
  }
  return true;
}

/**
 * Checks if image dimensions are within height and aspect ratio limits.
 * @param   {Object}  dimensions    of image {width: number, height: number}
 * @param   {Object}  imageOptions  contains minHeight, maxAspectRatio, and minAspectRatio
 * @returns {boolean} true if image height and aspect ratio are within limits, false otherwise.
 * @exception dimensions are null or dimensions don't fall within bounds specified in imageOptions
 */
function imageDimensionsValid(dimensions, imageOptions) {
  console.log(`imageDimensionsValid {dimensions : ${JSON.stringify(dimensions)}, `
    + `imageOptions : ${JSON.stringify(imageOptions)}}`);

  if (dimensions === null) {
    throw new ErrorWithStatusCode(' Unable to determine if image dimensions are valid. '
    + `Parameter "dimensions" has value "${JSON.stringify(dimensions)}".`, ERRORS.INTERNAL_SERVER_ERROR);
  }

  if ((dimensions.height < imageOptions.minHeight)
        || (dimensions.width / dimensions.height > imageOptions.maxAspectRatio)
        || (dimensions.width / dimensions.height < imageOptions.minAspectRatio)) {
    console.log('Image dimensions or aspect ratio not valid');
    return false;
  }
  return true;
}

/**
 * Fetches the image at the url and encodes it in base64 format.
 * @param   {string}  imageUrl        url pointing to image file
 * @param   {Object}  fetchOptions    contains max file size for download.
 * @returns {string}  base 64 image encoded as string
 * @exception image exceeds file size limit during download or error
 */
async function imageUrlToBase64Image(imageUrl, fetchOptions) {
  console.log(`imageUrlToBase64Image {imageUrl : ${imageUrl}, `
    + `fetchOptions : ${JSON.stringify(fetchOptions)}}`);

  let image;
  try {
    image = await fetch(imageUrl, fetchOptions);
  } catch (error) {
    throw new ErrorWithStatusCode(' Image downloading aborted, max file size '
        + 'reached or error occurred while downloading', ERRORS.INTERNAL_SERVER_ERROR);
  }

  const imageBuffer = await image.buffer();
  const imageBase64Encoded = imageBuffer.toString(ENCODING.BASE64);

  return imageBase64Encoded;
}

/**
 * Adds the correct uri prefix for the base64 encoded image so that it can be
 * displayed in the frontend (jpeg or png only).
 * @param   {string}  base64Image   base64 encoded image without uri prefix
 * @returns {string}  base64 encoded image with uri prefix, jpeg or png only
 */
function prependUriPrefixToBase64Image(base64Image) {
  console.log(`prependUriPrefixToBase64Image {base64Image : ${base64Image.substring(0,50)} [...] `
  + '(truncated for readability)}');

  switch (base64Image.substring(0, BASE64.FILETYPE_IDENTIFIER_LENGTH)) {
  case BASE64.FILETYPE_IDENTIFIER.PNG :
    return BASE64.URI_PREFIX.PNG + base64Image;
  case BASE64.FILETYPE_IDENTIFIER.JPEG :
    return BASE64.URI_PREFIX.JPEG + base64Image;
  default:
    throw new ErrorWithStatusCode('Unrecognized image file type.', ERRORS.INTERNAL_SERVER_ERROR);
  }
}

module.exports = {
  getImage,
  imageFilesizeWithinBounds,
  imageDimensionsValid,
  prependUriPrefixToBase64Image
};
