/**
 *  @file Handles downloading of websites' htmls and scraping of said htmls for
 *  title, description, and image url. Also handles creation of short urls.
 */

const fetch = require('node-fetch');
const messageUtils = require('./message');
const HTML = require('./../constants/html');
const METADATA_LIMITS = require('./../constants/metadataLimits');
const REGEXES = require('./../constants/regexes');
const STRING = require('./../constants/strings');
const SYMBOLS = require('./../constants/symbols');
const URL = require('./../constants/url');
const ERRORS = require('./../constants/errors');
const { ErrorWithStatusCode } = require('./../errors/ErrorWithStatusCode');

/**
 * Function that wraps node-fetch to download the html for a url.
 * @param   {string}  url   to download html for
 * @returns {string}  html  of url
 * @exception download timeout, download size limit reached, download error
 */
async function getHtmlFromUrl(url) {
  console.log(`getHtmlFromUrl {url : ${url}}`);

  try {
    const response = await fetch(
      url,
      {
        timeout: HTML.FETCH_PARAMETERS.TIMEOUT_MS,
        size: HTML.FETCH_PARAMETERS.MAX_SIZE_BYTES
      }
    );
    const html = await response.text();

    if (html === STRING.EMPTY_STRING) {
      throw new ErrorWithStatusCode('Unable to retrieve html for the url with '
        + `value "${url}.`, ERRORS.INTERNAL_SERVER_ERROR);
    }

    return html;
  } catch (error) {
    throw new ErrorWithStatusCode('Unable to retrieve html for the url with '
        + `value "${url}.`, ERRORS.INTERNAL_SERVER_ERROR);
  }
}

/**
 * Fetches html of the website given by url then scrapes it for tags. The general
 * idea behind the scrapers is to first check open graph tags (https://opengraphprotocol.org/)
 * then twitter card tags, (https://developer.twitter.com/en/docs/tweets/optimize-with-cards/overview/markup)
 * then, if both of those fail, either return null (image) or attempt to scrape
 * the html meta tags (title, description).
 *
 * @param   {string}  html  of website to scrape
 * @param   {string}  url   of html that is being scraped
 * @returns {Object}  containing the following fields: title, image, description, url
 * @exception if url unable to be scraped or title missing
 */
function getUrlMetadata(html, url) {
  console.log(`getUrlMetadata {html : [not displaying html due to length], url : ${url}}`);

  /**
     * If a title isn't found an error will thrown to the caller, as a title is
     * considered essential. If a description or image isn't found, an exception
     * will be thrown and handled locally, as these are not considered essential.
     */
  const titleRaw = scrapeTitle(html);
  const title = htmlToUtf(titleRaw);

  let description = null; // default value for description
  try {
    description = scrapeDescription(html);
    description = htmlToUtf(description);
  } catch (error) {
    console.error(error);
  }

  let image = null; // default value for image
  try {
    image = scrapeImageUrl(html, url);
  } catch (error) {
    console.error(error);
  }

  return {title, image, description, url};
}

/**
 * Converts html encoded string to utf string.
 *
 * The title and description string often contain html characters that need to
 * be decoded into unicode to display properly. This method uses a regex to find
 * the html characters then converts them into unicode if they fall within the
 * predetermined group of recognized html characters.
 *
 * @param   {string}  str   currently encoded in html, to be converted to utf encoding
 * @returns {string}  string with html characters replaced by their unicode equivilants
 */
function htmlToUtf(str) {
  console.log(`htmlToUtf {str : ${str}}`);

  return str.replace(
    REGEXES.HTML_CHARACTER, (utfChar, htmlChar) => {
      if (Object.prototype.hasOwnProperty.call(HTML.UNICODE_CHAR_MAPPING, htmlChar)) {
        return HTML.UNICODE_CHAR_MAPPING[htmlChar];
      } else { // In event it doesn't match, return the unmodified string.
        return htmlChar;
      }
    });
}

/**
 * Generalized tag scraper that returns string in the content section of the tag.
 * For example, if tag='og:title' and the html contains the following line:
 * <meta property="og:title" content="Amazon Web Services (AWS) -  Cloud Computing Services">
 *
 * then this function would return:
 * 'Amazon Web Services (AWS) -  Cloud Computing Services'
 *
 * @param   {string}  tag   to scrape
 * @param   {string}  html  of website to scrape
 * @exception if tag not found.
 */
function scrapeTag(tag, html) {
  console.log(`scrapeTag {tag : ${tag}, html: [not displaying html due to length]}`);

  const tagIndex = html.indexOf('"' + tag + '"');

  if (tagIndex < 0) {
    throw new ErrorWithStatusCode(`Tag with value "${tag}" not found.`, ERRORS.NOT_FOUND);
  }

  const contentTagIndex = html.indexOf('content', tagIndex);
  const dataWithQuotes = html.substring(
    html.indexOf('"', contentTagIndex), html.indexOf('>', tagIndex));
  const data = dataWithQuotes.substring(
    (dataWithQuotes.indexOf('"') + 1), dataWithQuotes.lastIndexOf('"'));

  if (data.length === 0) {
    throw new ErrorWithStatusCode(`Tag with value "${tag}" not found.`, ERRORS.NOT_FOUND);
  }

  return data;
}

/**
 * Attempts to scrape the title tag of the html parameter. Order of priority:
 *  1. og:title
 *  2. twitter:title
 *  3. meta title
 *
 * @param   {string}  html  of website to scrape
 * @returns {string}  title
 * @exception title not found
 */
function scrapeTitle(html) {
  console.log('scrapeTitle {html: [not displaying html due to length]}');

  try {
    const ogTitle = scrapeTag(HTML.TAGS.OG_TITLE, html);
    console.log(`Using ${HTML.TAGS.OG_TITLE}`);
    return ogTitle;
  } catch (error) {
    console.error(error);
  }

  try {
    const twitterTitle = scrapeTag(HTML.TAGS.TWITTER_TITLE, html);
    console.log(`Using ${HTML.TAGS.TWITTER_TITLE}`);
    return twitterTitle;
  } catch (error) {
    console.error(error);
  }

  try {
    const htmlTitle = scrapeHtmlTitle(html);
    console.log(`Using html ${HTML.TAGS.HTML_TITLE}`);
    return htmlTitle;
  } catch (error) {
    console.error(error);
  }

  throw new ErrorWithStatusCode('Title not found.', ERRORS.NOT_FOUND);
}

/**
 * Meta title scraper. Requires different rules than the general tag scraper.
 *
 * Returns string in the <title> section of the html. For example, if the html
 * contained the following line:
 * <title>Amazon Web Services (AWS) -  Cloud Computing Services</title>
 *
 * then this function would return:
 * 'Amazon Web Services (AWS) -  Cloud Computing Services'
 *
 * @param   {string}  html  of website to scrape
 * @returns {string}  title scraped from html
 * @exception title not found
 */
function scrapeHtmlTitle(html) {
  console.log('scrapeHtmlTitle {html : [html not shown here due to length] }');

  const titleTagIndex = html.indexOf(HTML.TAGS.HTML_TITLE);

  if (titleTagIndex < 0) {
    throw new ErrorWithStatusCode(` Tag with value "${HTML.TAGS.HTML_TITLE}" `
      + 'not found.', ERRORS.NOT_FOUND);
  }

  const titleTagEndIndex = html.indexOf('>', titleTagIndex) + 1;
  const titleWithQuotes = html.substring(
    titleTagEndIndex, html.indexOf('<', titleTagEndIndex));

  let response;
  // Addresses edge case where the html title is delimited by quotes ("").
  if (titleWithQuotes.indexOf('"') >= 0
      && titleWithQuotes.indexOf('"') !== titleWithQuotes.lastIndexOf('"')) {
    response = titleWithQuotes.substring(
      (titleWithQuotes.indexOf('"') + 1), titleWithQuotes.lastIndexOf('"'));
  } else {
    response = titleWithQuotes;
  }

  if (response.length === 0) {
    throw new ErrorWithStatusCode(`Tag with value "${HTML.TAGS.HTML_TITLE}" `
      + 'not found.', ERRORS.NOT_FOUND);
  }

  return response;
}

/**
 * Attempts to scrape the description tag of the html parameter. Order of priority:
 *  1. og:description
 *  2. twitter:description
 *  3. meta description
 * @param     {string}  html  of website to scrape
 * @returns   {string}  description scraped from html
 * @exception description not found
 */
function scrapeDescription(html) {
  console.log('scrapeDescription {html: [not displaying html due to length]}');

  try {
    const ogDescription = scrapeTag(HTML.TAGS.OG_DESCRIPTION, html);
    if (ogDescription.length > METADATA_LIMITS.MINIMUM.MAX_DESCRIPTION_LENGTH) {
      console.log(`Using ${HTML.TAGS.OG_DESCRIPTION}`);
      return ogDescription;
    }
  } catch (error) {
    console.error(error);
  }

  try {
    const twitterDescription = scrapeTag(HTML.TAGS.TWITTER_DESCRIPTION, html);
    if (twitterDescription.length > METADATA_LIMITS.MINIMUM.MAX_DESCRIPTION_LENGTH) {
      console.log(`Using ${HTML.TAGS.TWITTER_DESCRIPTION}`);
      return twitterDescription;
    }
  } catch (error) {
    console.error(error);
  }

  try {
    const metaDescription = scrapeMetaDescription(html);
    if (metaDescription.length > METADATA_LIMITS.MINIMUM.MAX_DESCRIPTION_LENGTH) {
      console.log(`Using ${HTML.TAGS.META_DESCRIPTION}`);
      return metaDescription;
    }
  } catch (error) {
    console.error(error);
  }

  throw new ErrorWithStatusCode('Description not found.', ERRORS.NOT_FOUND);
}

/**
 * Meta description scraper. Requires different rules than the general tag scraper.
 *
 * Returns string in the meta description section of the html. For example, if
 * the html contained the following line:
 * <meta name="description" content="Amazon Web Services offers reliable, scalable,
 * and  inexpensive cloud computing services. Free to join, pay only for what you use.">
 *
 * then this function would return:
 * 'Amazon Web Services offers reliable, scalable, and  inexpensive cloud computing
 * services. Free to join, pay only for what you use.'
 *
 * @param   {string}  html    of websites to scrape
 * @returns {string}  description scraped from html
 * @exception description not found
 */
function scrapeMetaDescription(html) {
  console.log('scrapeMetaDescription {html: [not displaying html due to length]}');

  const tagIndex = html.indexOf(HTML.TAGS.META_DESCRIPTION);
  if (tagIndex < 0) {
    throw new ErrorWithStatusCode(`Tag with value "${HTML.TAGS.META_DESCRIPTION}" `
      + 'not found.', ERRORS.NOT_FOUND);
  }

  const contentTagIndex = html.indexOf('content', tagIndex);
  const dataWithQuotes = html.substring(
    html.indexOf('"', contentTagIndex), html.indexOf('>', tagIndex));
  const data = dataWithQuotes.substring(
    (dataWithQuotes.indexOf('"') + 1), dataWithQuotes.lastIndexOf('"'));

  if (data.length === 0) {
    throw new ErrorWithStatusCode(`Tag with value "${HTML.TAGS.META_DESCRIPTION}" `
      + 'not found.', ERRORS.NOT_FOUND);
  }

  return data;
}

/**
 * Attempts to scrape the image tag of the html parameter. Only checks for og:image
 * because it's extremely uncommon to find a website with a twitter image tag that
 * does not have an og:image tag. Also, the html of the website isn't scraped because
 * this would be a time expensive task that would require evaluating several images,
 * all of which could be a good or bad image candidate.
 * Also employs a separate Amazon scraper to scrape Amazon retail websites for
 * their product image, as they are placed in non-traditional locations.
 * @param   {string}  html      of website to scrape
 * @param   {string}  targetUrl of website to scrape
 * @returns {string}  image url
 * @exception image not found
 */
function scrapeImageUrl(html, targetUrl) {
  console.log('scrapeImageUrl {html: [not displaying html due to length]}');

  console.log(html);
  // Amazon retail urls (www.amazon.com/*) require a custom image scraper
  if (isAmazonRetailUrl(targetUrl)) {
    const tagIndex = html.indexOf(HTML.TAGS.AMAZON_IMAGE_TAG);
    const dataBlock = html.substring(
      html.indexOf('"', tagIndex) + 1, html.indexOf('>', tagIndex));
    const amazonImage = dataBlock.substring(0, dataBlock.indexOf('"'));

    if (amazonImage === null) {
      throw new ErrorWithStatusCode('Amazon retail product image not found.', ERRORS.NOT_FOUND);
    }
    if (!messageUtils.isValidUrl(amazonImage)) {
      throw new ErrorWithStatusCode('Amazon retail product image not found.', ERRORS.NOT_FOUND);
    }

    console.log('Using Amazon retail image.');
    return amazonImage;
  } else {

    let ogImage = scrapeTag(HTML.TAGS.OG_IMAGE, html);
    if (ogImage === null) {
      throw new ErrorWithStatusCode('Image not found.', ERRORS.NOT_FOUND);
    }

    if (ogImage.indexOf('"') > 0) {
      ogImage = ogImage.substring(0, ogImage.indexOf('"'));
    }
    if (!messageUtils.isValidUrl(ogImage)) {
      throw new ErrorWithStatusCode('Image not found.', ERRORS.NOT_FOUND);
    }

    console.log(`Using ${HTML.TAGS.OG_IMAGE}`);
    return ogImage;
  }
}

/**
 * Checks if url is Amazon retail url.
 * @param   {string}  url   to check
 * @returns {boolean} true if url is an amazon retail url, false otherwise.
 */
function isAmazonRetailUrl(url) {
  console.log(`isAmazonRetailUrl {url : ${url}}`);

  for (const tld of URL.RECOGNIZED_TLDS) {
    /**
     *  Some international amazon websites are formatted 'amazon.INTERNATIONAL_TLD',
     *  while others are formatted 'amazon.com.INTERNATIONAL_TLD'.
     */
    if (url.includes(URL.AMAZON_RETAIL_URL_WITHOUT_TLD + '.' + tld)
        || url.includes(URL.AMAZON_RETAIL_URL_WITHOUT_TLD + '.com' + tld)) {
      return true;
    }
  }
  return false;
}

/**
 * Checks that title is within the minimum and maximum lengths allowed, throws error
 * if it's length is less than the minimum, or truncates it and adds "..." to the
 * end if it is greater than the maximum (so the final length is === maximum).
 * @param   {string}  title           to be formatted
 * @param   {string}  maxTitleLength  allowed
 * @returns {string}  title that is between lengths minimum and maximum, inclusive
 * @exception title is too short
 */
function formatTitle(title, maxTitleLength) {
  console.log(`getTitle {title : ${title}, `
    + `maxTitleLength : ${maxTitleLength}}`);

  /*
   * No null check is needed here. If title === null, an error will be thrown
   * during scraping, and execution will not reach this point.
   */

  title = title.trim();
  if (title.length < METADATA_LIMITS.MINIMUM.TITLE_LENGTH) {
    throw new ErrorWithStatusCode(' Title scraped from url has length '
      + `"${title.length}" which is shorter than the minimum length of `
      + `"${METADATA_LIMITS.MINIMUM.TITLE_LENGTH}" allowed.`, ERRORS.INTERNAL_SERVER_ERROR);
  }

  if (title.length > maxTitleLength) {
    title = title.substring(
      0, maxTitleLength - STRING.ELLIPSIS.length) + STRING.ELLIPSIS;
  }
  return title;
}

/**
 * Checks that description is within the minimum and maximum lengths allowed, throws error
 * if it's length is less than the minimum, or truncates it and adds "..." to the
 * end if it is greater than the maximum (so the final length is === maximum).
 * @param   {string}    description           to be formatted
 * @param   {string}    maxDescriptionLength  allowed
 * @returns {string}  description that is between lengths minimum and maximum, inclusive
 * @exception description is too short
 */
function formatDescription(description, maxDescriptionLength) {
  console.log(`getDescription {description : ${description}, `
    + `maxDescriptionLength : ${maxDescriptionLength}}`);

  if (description === null) {
    throw new ErrorWithStatusCode('Description scraped from url is null.', ERRORS.INTERNAL_SERVER_ERROR);
  }

  description = description.trim();
  if (description.length < METADATA_LIMITS.MINIMUM.DESCRIPTION_LENGTH) {
    throw new ErrorWithStatusCode(' Description scraped from url has length '
        + `"${description.length}" which is shorter than the minimum length of `
        + `"${METADATA_LIMITS.MINIMUM.DESCRIPTION_LENGTH}" allowed.`, ERRORS.INTERNAL_SERVER_ERROR);
  }

  if (description.length > maxDescriptionLength) {
    description = description.substring(
      0, maxDescriptionLength - STRING.ELLIPSIS.length) + STRING.ELLIPSIS;
  }
  return description;
}


/**
 * Shortens urls for most common TLDs (95+% of all internet traffic)
 * Sample input:
 * https://aws.amazon.com/connect/
 * Sample output:
 * https://aws.amazon.com/
 * @param   {string}  fullUrl   full-length url
 * @returns {string} shortened url
 * @exception short url unable to be created, likely because url doesn't contain a path
 */
function getShortUrl(fullUrl) {
  console.log(`getShortUrl {fullUrl : ${fullUrl}}`);

  for (const tld of URL.RECOGNIZED_TLDS) {
    const fullTld = SYMBOLS.PERIOD + tld + SYMBOLS.FORWARD_SLASH;
    const tldIndex = fullUrl.indexOf(fullTld);
    if (tldIndex > 0) {
      return fullUrl.substring(0, tldIndex + fullTld.length);
    }
  }
  throw new ErrorWithStatusCode(`Short url unable to be created for url "${fullUrl}`, ERRORS.INTERNAL_SERVER_ERROR);
}


module.exports = {
  getHtmlFromUrl,
  getUrlMetadata,
  formatTitle,
  formatDescription,
  getShortUrl,
  /**
   * All functions below this comment are exported solely for testing purposes
   * and are not used elsewhere in the package.
   */
  scrapeTag,
  scrapeTitle,
  scrapeHtmlTitle,
  scrapeDescription,
  scrapeMetaDescription,
  scrapeImageUrl,
  isAmazonRetailUrl,
};
