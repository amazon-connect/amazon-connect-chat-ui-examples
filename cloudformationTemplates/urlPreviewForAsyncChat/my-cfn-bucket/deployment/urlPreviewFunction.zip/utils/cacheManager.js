/**
 * @file Handles all interactions with DynamoDB cache.
 */

const AWS = require('aws-sdk');
const CACHE = require('./../constants/cache');
const ERRORS = require('./../constants/errors');
const { ErrorWithStatusCode } = require('./../errors/ErrorWithStatusCode');

/**
 * Updates AWS configuration settings. Does not return a value.
 * @param   {Object}    config      could contain any subset of the following options:
 *                                  {
 *                                    region: string,
 *                                    endpoint: string,
 *                                    accessKeyId: string,
 *                                    secretAccessKey: string
 *                                  }
 */
function updateConfiguration(config = {}) {
  console.log(`updateConfiguration {config : ${JSON.stringify(config)}}`);

  // Default values are stored in the lambda's environment variables
  const updatedRegion = config.region || process.env.AWS_REGION;
  const updatedEndpoint = config.endpoint || process.env.DDB_CACHE_ENDPOINT;
  const updatedAccessKeyId = config.accessKeyId || process.env.DDB_CACHE_ACCESS_KEY;
  const updatedSecretAccessKey = config.secretAccessKey || process.env.DDB_CACHE_SECRET_ACCESS_KEY;

  console.log('updateConfiguration updating AWS config with the following settings '
      + `{region : ${updatedRegion}, endpoint : ${updatedEndpoint}}`);

  AWS.config.update({
    region: updatedRegion,
    endpoint: updatedEndpoint,
    // accessKeyId default can be used while using the downloadable version of DynamoDB.
    // For security reasons, do not store AWS Credentials in your files. Use Amazon Cognito instead.
    accessKeyId: updatedAccessKeyId,
    // secretAccessKey default can be used while using the downloadable version of DynamoDB.
    // For security reasons, do not store AWS Credentials in your files. Use Amazon Cognito instead.
    secretAccessKey: updatedSecretAccessKey
  });
}

/**
 * Checks if normalized url has entry in DynamoDB cache.
 * @param       {string}    normalizedUrl   normalizedUrl to check for in cache
 * @returns     {Object}    data from cache
 * @exception   item not found
 */
async function getMetadata(normalizedUrl) {
  console.log(`getMetadata {normalizedUrl : ${normalizedUrl}}`);

  const { PRIMARY_KEY, TABLE_NAME } = CACHE;
  const params = {
    TableName: TABLE_NAME,
    Key: {
      [PRIMARY_KEY]: normalizedUrl,
    }
  };

  const docClient = new AWS.DynamoDB.DocumentClient();
  let data;
  try {
    data = await docClient.get(params).promise();
  } catch (error) {
    throw new ErrorWithStatusCode(`Unable to read item. Error JSON: ${JSON.stringify(error, null, 2)}`, ERRORS.INTERNAL_SERVER_ERROR);
  }

  // Validates returned data
  if (data && data.Item && data.Item[PRIMARY_KEY] === normalizedUrl) {
    console.log(`normalizedUrlIsInCache successfully retrieved item: ${JSON.stringify(data, null, 2)}`);

    return data;
  } else {
    throw new ErrorWithStatusCode(`Data not found in cache. Table name: "${TABLE_NAME}", Primary key: "${PRIMARY_KEY}".`, ERRORS.NOT_FOUND);
  }
}

/**
 * Adds metadata to DynamoDB cache.
 * @param       {Object}    metadata        metadata object
 * @param       {number}    ttl             unix time to live for cache entry, default is 30 days
 * @returns     {Object}    data added to cache
 * @exception   unable to add item
 */
async function putMetadata(metadata, ttl) {
  console.log(`putMetadata {metadata : ${metadata}, ttl : ${ttl}}`);

  /**
   * Normalized url is used as the primary key in the cache, so it needs to be
   * separate from the metadata object.
   */
  const normalizedUrl = metadata.url;
  delete metadata.url;

  // If ttl is not provided as a parameter, sets default ttl as defined in constants.js
  if (!ttl || ttl <= Math.floor(Date.now())) {
    ttl = Math.floor(Date.now() / CACHE.MILLISECONDS_PER_SECOND) + CACHE.DEFAULT_TTL;
  }

  const { PRIMARY_KEY, METADATA_COLUMN_NAME, TTL_COLUMN_NAME, TABLE_NAME } = CACHE;
  const item = {
    [PRIMARY_KEY]: normalizedUrl,
    [METADATA_COLUMN_NAME]: metadata,
    [TTL_COLUMN_NAME]: ttl
  };
  const params = {
    TableName: TABLE_NAME,
    Item: item
  };

  const docClient = new AWS.DynamoDB.DocumentClient();
  try {
    await docClient.put(params).promise();
    console.log(`addMetadataToCache successfully added item: ${JSON.stringify(params, null, 2)}`);

    return params;
  } catch (error) {
    throw new ErrorWithStatusCode(`Unable to add item. Error JSON: ${JSON.stringify(error, null, 2)}`, ERRORS.INTERNAL_SERVER_ERROR);
  }
}

/**
 * Parses object returned from the cache into the expected metadata format.
 * @param   {Object}    cacheItem   returned from the DynamoDB cache
 * @returns {Object}    metadata object in expected object format:
 *                      {
 *                          url,
 *                          shortUrl,
 *                          title,
 *                          description,
 *                          image
 *                      }
 */
function parseMetadataItemFromCache(cacheItem) {
  console.log(`parseMetadataItemFromCache {${JSON.stringify(cacheItem)}}`);

  const metadata = {};
  /**
     * By setting the values of the metadata object keys to null before assigning
     * them to the values from cacheItem, it ensures that any missing values from
     * the cacheItem are set to null (the expected behavior).
     */
  const { PRIMARY_KEY, METADATA_COLUMN_NAME, NULL_METADATA_OBJECT } = CACHE;
  Object.assign(metadata, NULL_METADATA_OBJECT);
  metadata.url = cacheItem.Item[PRIMARY_KEY];
  Object.assign(metadata, cacheItem.Item[METADATA_COLUMN_NAME]);

  return metadata;
}

module.exports = {
  updateConfiguration,
  getMetadata,
  putMetadata,
  parseMetadataItemFromCache
};