/**
 * @file Handles input validation.
 */

const DEFAULTS = require('./../constants/defaults');
const ENCODING = require('./../constants/encoding');
const METADATA_LIMITS = require('./../constants/metadataLimits');
const ERRORS = require('./../constants/errors');
const { ErrorWithStatusCode } = require('./../errors/ErrorWithStatusCode');

/**
 * Validates message input
 * @param       {string}    message     the message to be validated
 * @returns     {string}    the message string
 * @exception   message is null or has 0 non-space characters
 */
function validateMessage(message) {
  if (message === null) {
    throw new ErrorWithStatusCode('User input "message" is null.', ERRORS.BAD_REQUEST);
  }
  if (message.trim().length === 0) {
    throw new ErrorWithStatusCode('User input "message" has 0 non-space characters.', ERRORS.BAD_REQUEST);
  }
  return message;
}

/**
 * Checks each option to see if it exists and is within the allowed range.
 * For each option that does not exist or is outside the allowed range, sets it
 * to the default value.
 *
 * For inputs that are expected to be integers, their types are checked before
 * comparisons are made. If that test passes, the input does not need to be parsed
 * into an integer for comparisons with METADATA_LIMITS, as the METADATA_LIMITS values
 * are integers, and javascript will do integer comparison if at least 1 of the variables
 * being compared is an integer. If an integer input passes all tests, it is parsed
 * to an integer before being returned and used in the rest of the logic.
 *
 * @param   {Object}  options  the options inputted by the user, could include
 *                             any of the keys in the returned Object
 * @returns {Object}  {
 *                      minHeight: number,
 *                      maxAspectRatio: number,
 *                      maxDescriptionLength: number,
 *                      minAspectRatio: number,
 *                      timeoutMs: number,
 *                      maxUrlCount: number,
 *                      maxTitleLength: number,
 *                      maxImageSizeBytes: number
 *                    }
 */
function validateOptions(options = {}) {
  const timeoutMs = (
    options.timeoutMs
      && parseInt(options.timeoutMs, ENCODING.BASE10)
      && options.timeoutMs >= METADATA_LIMITS.MINIMUM.TIMEOUT_MS
      && options.timeoutMs <= METADATA_LIMITS.MAXIMUM.TIMEOUT_MS
  )
    ? parseInt(options.timeoutMs, ENCODING.BASE10) : DEFAULTS.TIMEOUT_MS;

  const maxTitleLength = (
    options.maxTitleLength
      && parseInt(options.maxTitleLength, ENCODING.BASE10)
      && options.maxTitleLength >= METADATA_LIMITS.MINIMUM.MAX_TITLE_LENGTH
      && options.maxTitleLength <= METADATA_LIMITS.MAXIMUM.MAX_TITLE_LENGTH
  )
    ? parseInt(options.maxTitleLength, ENCODING.BASE10) : DEFAULTS.METADATA.MAX_TITLE_LENGTH;

  const maxDescriptionLength = (
    options.maxDescriptionLength
      && options.maxDescriptionLength >= METADATA_LIMITS.MINIMUM.MAX_DESCRIPTION_LENGTH
      && options.maxDescriptionLength <= METADATA_LIMITS.MAXIMUM.MAX_DESCRIPTION_LENGTH
  )
    ? options.maxDescriptionLength : DEFAULTS.METADATA.MAX_DESCRIPTION_LENGTH;

  const maxUrlCount = (
    options.maxUrlCount
      && parseInt(options.maxUrlCount, ENCODING.BASE10)
      && options.maxUrlCount >= METADATA_LIMITS.MINIMUM.MAX_URL_COUNT
      && options.maxUrlCount <= METADATA_LIMITS.MAXIMUM.MAX_URL_COUNT
  )
    ? parseInt(options.maxUrlCount, ENCODING.BASE10) : DEFAULTS.MESSAGE.MAX_URL_COUNT;

  // Default value is true
  const shouldValidateImagePreDownload = (
    options.shouldValidateImagePreDownload === 'false'
      || options.shouldValidateImagePreDownload === false
  )
    ? false : DEFAULTS.IMAGE.SHOULD_VALIDATE_IMAGE_PRE_DOWNLOAD;

  const minHeight = (
    options.minHeight
      && parseInt(options.minHeight, ENCODING.BASE10)
      && options.minHeight >= METADATA_LIMITS.MINIMUM.MIN_HEIGHT
      && options.minHeight <= METADATA_LIMITS.MAXIMUM.MIN_HEIGHT
  )
    ? parseInt(options.minHeight, ENCODING.BASE10) : DEFAULTS.IMAGE.MIN_HEIGHT;

  console.log(options.minAspectRatio);
  const minAspectRatio = (
    options.minAspectRatio
      && parseInt(options.minAspectRatio, ENCODING.BASE10)
      && options.minAspectRatio >= METADATA_LIMITS.MINIMUM.MIN_ASPECT_RATIO
      && options.minAspectRatio <= METADATA_LIMITS.MAXIMUM.MIN_ASPECT_RATIO
  )
    ? parseInt(options.minAspectRatio, ENCODING.BASE10) : DEFAULTS.IMAGE.MIN_ASPECT_RATIO;

  const maxAspectRatio = (
    options.maxAspectRatio
      && parseInt(options.maxAspectRatio, ENCODING.BASE10)
      && options.maxAspectRatio >= METADATA_LIMITS.MINIMUM.MAX_ASPECT_RATIO
      && options.maxAspectRatio <= METADATA_LIMITS.MAXIMUM.MAX_ASPECT_RATIO
  )
    ? parseInt(options.maxAspectRatio, ENCODING.BASE10) : DEFAULTS.IMAGE.MAX_ASPECT_RATIO;

  const maxImageSizeBytes = (
    options.maxImageSizeBytes
      && parseInt(options.maxImageSizeBytes, ENCODING.BASE10)
      && options.maxImageSizeBytes >= METADATA_LIMITS.MINIMUM.MAX_IMAGE_SIZE_BYTES
      && options.maxImageSizeBytes <= METADATA_LIMITS.MAXIMUM.MAX_IMAGE_SIZE_BYTES
  )
    ? parseInt(options.maxImageSizeBytes, ENCODING.BASE10) : DEFAULTS.IMAGE.MAX_IMAGE_SIZE_BYTES;

  return {
    timeoutMs,
    maxTitleLength,
    maxDescriptionLength,
    maxUrlCount,
    shouldValidateImagePreDownload,
    minHeight,
    minAspectRatio,
    maxAspectRatio,
    maxImageSizeBytes
  };
}

module.exports = {
  validateMessage,
  validateOptions
};