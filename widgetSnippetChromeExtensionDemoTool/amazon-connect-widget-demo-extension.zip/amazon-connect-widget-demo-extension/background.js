// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

/**
 * Handles Content Security Policy (CSP) issues by filtering headers with names
 * 'content-security-policy' or 'x-frame-options' using the 'stripHeaders' function.
 *
 * Intercepts web requests with 'chrome.webRequest.onHeadersReceived' listener,
 * modifies the response headers using 'stripHeaders', and returns them to the browser.
 */

function stripHeaders(headers) {
  return headers.filter((header) => {
    let headerName = header.name.toLowerCase();
    return !(headerName === 'content-security-policy' || headerName === 'x-frame-options');
  });
}
window.stripHeaders = stripHeaders;

chrome.webRequest.onHeadersReceived.addListener(
  function (details) {
    return {
      responseHeaders: stripHeaders(details.responseHeaders)
    };
  },
  {
    urls: ['<all_urls>']
  },
  ['blocking', 'responseHeaders']
);
