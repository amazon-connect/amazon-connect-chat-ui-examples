// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

window.handleInjectBtnClick = function handleInjectBtnClick() {
  const textAreaSnippetInput = window.retreiveTextAreaInputValue();

  window.retreiveItemFromLocalStorage(window.SNIPPET_STORAGE_KEY, (storedSnippet) => {
    const widgetToInject = textAreaSnippetInput || storedSnippet;

    window.isExtensionStillEnabled(
      (isEnabled) => isEnabled && window.injectWidgetSnippetIntoWebpage(widgetToInject),
      () => alert('Demo has been disabled!')
    );
  });
};

window.handleTextAreaInputChange = function handleTextAreaInputChange(event) {
  const clipboardData = event.clipboardData || window.clipboardData;
  const pastedClipboardText = clipboardData && clipboardData.getData('text');
  const widgetToInject = event.target.value || pastedClipboardText;

  window.storeItemInLocalStorage(window.SNIPPET_STORAGE_KEY, widgetToInject);

  window.isExtensionStillEnabled((isEnabled) => isEnabled && window.injectWidgetSnippetIntoWebpage(widgetToInject));
};

window.handleToggleBtnChange = function handleToggleBtnChange() {
  window.isExtensionStillEnabled((isEnabled) => {
    const newExtensionToggleStatus = isEnabled ? 'IS_NOW_DISABLED' : '';

    window.storeItemInLocalStorage(window.DEMO_DISABLED_FLAG_KEY, newExtensionToggleStatus);

    if (newExtensionToggleStatus === 'IS_NOW_DISABLED') {
      window.clearExistingWidgetElems();
    }
  });
};

window.clearExistingWidgetElems = function clearExistingWidgetElems() {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.executeScript(tabs[0].id, {
      code: `
        // Remove existing widget elem if present
        var existingChatWidgetElem = document.querySelectorAll('[id="${window.AMAZON_CONNECT_CHAT_WIDGET_ROOT_ID}"]');
        for(var i = 0; i < existingChatWidgetElem.length; i++) {
          existingChatWidgetElem[i].remove();
        }
      `
    });
  });
};

window.handleResetBtnClick = function handleResetBtnClick() {
  // Reset all stored values
  window.setTextAreaSnippetInput('');
  window.storeItemInLocalStorage(window.SNIPPET_STORAGE_KEY, '');
  window.storeItemInLocalStorage(window.DEMO_DISABLED_FLAG_KEY, '');

  window.clearExistingWidgetElems();
};
