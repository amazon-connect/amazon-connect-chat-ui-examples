// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

// Expected elements
window.INJECT_BTN_ID = 'widget-snippet-inject-btn';
window.SNIPPET_TEXTAREA_ID = 'widget-snippet-paste-input';
window.TOGGLE_BTN_ID = 'widget-snippet-toggle-switch';
window.RESET_BTN_ID = 'widget-snippet-reset-btn';
window.AMAZON_CONNECT_CHAT_WIDGET_ROOT_ID = 'amazon-connect-chat-widget';

// LocalStorage keys
window.SNIPPET_STORAGE_KEY = 'connect-widget-demo-snippet-code';
window.DEMO_DISABLED_FLAG_KEY = 'connect-widget-demo-tool-disabled';
