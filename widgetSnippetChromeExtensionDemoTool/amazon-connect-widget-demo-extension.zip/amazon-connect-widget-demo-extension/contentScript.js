// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

// This script is executed in the current browser tab on load

window.SNIPPET_STORAGE_KEY = 'connect-widget-demo-snippet-code';
window.DEMO_DISABLED_FLAG_KEY = 'connect-widget-demo-tool-disabled';
window.AMAZON_CONNECT_CHAT_WIDGET_ROOT_ID = 'amazon-connect-chat-widget';

/**
 * Attempt to pre-load the widget snippet.
 * Loaded from string in localStorage
 */
window.initializeSavedWidgetSnippet = function initializeSavedWidgetSnippet() {
  let savedWidgetSnippet = localStorage.getItem(`${window.SNIPPET_STORAGE_KEY}`);

  if (savedWidgetSnippet) {
    // Remove existing widget elem if present
    let existingChatWidgetElem = document.querySelectorAll(`[id="${window.AMAZON_CONNECT_CHAT_WIDGET_ROOT_ID}"]`);
    for (let i = 0; i < existingChatWidgetElem.length; i++) {
      existingChatWidgetElem[i].remove();
    }

    // Inject the script into the current webpage
    let script = document.createElement('script');
    script.type = 'text/javascript';
    script.innerHTML = savedWidgetSnippet.replace(/<\/?script[^>]*>/g, '');
    document.head.appendChild(script);
  }
};

/**
 * Checks if the user has chosen to disable the extension
 * Enabled by default, adding the localStorage key will override
 */
window.isExtensionEnabled = function isExtensionEnabled() {
  const demoHasBeenDisabled = !!localStorage.getItem(`${window.DEMO_DISABLED_FLAG_KEY}`);

  return !demoHasBeenDisabled;
};

if (window.isExtensionEnabled()) {
  window.initializeSavedWidgetSnippet();
}
