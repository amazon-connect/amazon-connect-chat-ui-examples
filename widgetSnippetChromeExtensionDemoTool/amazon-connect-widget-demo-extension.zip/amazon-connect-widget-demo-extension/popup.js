// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

window.injectWidgetSnippetIntoWebpage = function injectWidgetSnippetIntoWebpage(snippetString) {
  console.log('typeof snippetString', typeof snippetString, snippetString);
  const formattedJSSnippet = snippetString.replace(/<\/?script[^>]*>/g, '');

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.executeScript(tabs[0].id, {
      code: `
        // Remove existing widget elem if present
        var existingChatWidgetElem = document.querySelectorAll('[id="${window.AMAZON_CONNECT_CHAT_WIDGET_ROOT_ID}"]');
        for(var i = 0; i < existingChatWidgetElem.length; i++) {
          existingChatWidgetElem[i].remove();
        }

        var script = document.createElement("script");
        script.type = "text/javascript";
        script.innerHTML = \`${formattedJSSnippet}\`;
        document.head.appendChild(script);
      `
    });
  });
};

window.initializePopupButtonListeners = function initializePopup() {
  const injectScriptBtn = document.getElementById(window.INJECT_BTN_ID);
  if (injectScriptBtn) {
    injectScriptBtn.addEventListener('click', window.handleInjectBtnClick);
  }
  const textAreaInput = document.getElementById(window.SNIPPET_TEXTAREA_ID);
  if (textAreaInput) {
    textAreaInput.addEventListener('change', window.handleTextAreaInputChange);
  }
  const toggleExtensionBtn = document.getElementById(window.TOGGLE_BTN_ID);
  if (toggleExtensionBtn) {
    toggleExtensionBtn.addEventListener('change', window.handleToggleBtnChange);
  }
  const extensionResetBtn = document.getElementById(window.RESET_BTN_ID);
  if (extensionResetBtn) {
    extensionResetBtn.addEventListener('click', window.handleResetBtnClick);
  }
};

window.initializeWidgetOnPopupLoad = function initializeWidgetOnPopupLoad() {
  window.isExtensionStillEnabled((extensionIsRunning) => {
    document.getElementById(window.TOGGLE_BTN_ID).checked = extensionIsRunning;

    // Check if there is a previously stored user widget
    window.retreiveItemFromLocalStorage(window.SNIPPET_STORAGE_KEY, (localSavedWidgetSnippet) => {
      if (localSavedWidgetSnippet && extensionIsRunning) {
        window.injectWidgetSnippetIntoWebpage(localSavedWidgetSnippet);
        window.setTextAreaSnippetInput(localSavedWidgetSnippet);
      }
    });
  });
};

document.addEventListener('DOMContentLoaded', function () {
  // Add global event listeners to 'popup.html' elements
  window.initializePopupButtonListeners();

  // Check user settings for DISABLE FLAG + update the toggle switch element
  window.initializeWidgetOnPopupLoad();
});
