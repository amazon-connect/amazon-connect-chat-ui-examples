// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

window.isExtensionStillEnabled = function isExtensionStillEnabled(callback) {
  // Extension enabled by default, unless user has set override flag to disable
  window.retreiveItemFromLocalStorage(window.DEMO_DISABLED_FLAG_KEY, (result) => {
    callback(result === 'IS_NOW_DISABLED' ? false : true);
  });
};

window.retreiveItemFromLocalStorage = function retreiveItemFromLocalStorage(key, callback) {
  // Fetch from the extension localStorage
  const extenstionStorageValue = localStorage.getItem(key);

  // Fetch from the browser localStorage
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.executeScript(
      tabs[0].id,
      {
        code: `localStorage.getItem("${key}");`
      },
      function (userStorageValue) {
        if (typeof callback === 'function') {
          let storageValueReturned = extenstionStorageValue || userStorageValue;
          callback(storageValueReturned);
        }
      }
    );
  });
};

window.storeItemInLocalStorage = function storeItemInLocalStorage(key, value) {
  // Save to the extension localStorage
  localStorage.setItem(key, value);

  // Save to the browser localStorage
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.executeScript(tabs[0].id, {
      code: `var item = localStorage.setItem("${key}", \`${value}\`);`
    });
  });
};

window.retreiveTextAreaInputValue = function retreiveTextAreaInputValue() {
  const textAreaSnippetInput = document.getElementById(window.SNIPPET_TEXTAREA_ID);
  if (textAreaSnippetInput) {
    return textAreaSnippetInput.value;
  }
};

window.setTextAreaSnippetInput = function setTextAreaSnippetInput(snippetString) {
  const textAreaSnippetInput = document.getElementById(window.SNIPPET_TEXTAREA_ID);
  if (textAreaSnippetInput) {
    textAreaSnippetInput.value = snippetString;
  }
};
